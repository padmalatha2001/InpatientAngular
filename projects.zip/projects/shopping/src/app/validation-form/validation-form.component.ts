import { Component } from '@angular/core';

@Component({
  selector: 'app-validation-form',
  templateUrl: './validation-form.component.html',
  styleUrl: './validation-form.component.css'
})
export class ValidationFormComponent {

}
