import { Component } from '@angular/core';

@Component({
  selector: 'app-mens',
  templateUrl: './mens.component.html',
  styleUrl: './mens.component.css'
})
export class MensComponent {

}
