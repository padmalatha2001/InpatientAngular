import { Component } from '@angular/core';

@Component({
  selector: 'app-womens',
  templateUrl: './womens.component.html',
  styleUrl: './womens.component.css'
})
export class WomensComponent {

}
