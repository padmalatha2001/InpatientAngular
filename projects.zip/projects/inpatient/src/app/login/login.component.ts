import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
 click(){
  
 }

// constructor(private b:FormBuilder){}
// public loginformref=this.b.group({
//   Email:this.b.control('',[Validators.required,Validators.email]),
//   Password:this.b.control('',[Validators.required,Validators.minLength(5)])
// })
//  onSubmit() {
//   if (this.myForm.valid) {
//     // Form is valid, handle submission
//     console.log(this.myForm.value);
//   } else {
//     // Form is invalid, show error messages
//     console.log("Form is invalid");
//   }
//   }
}

