import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RoomTypeComponent } from './room-type/room-type.component';
import { HomeComponent } from './home/home.component';
import { DetailsComponent } from './details/details.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { LoginComponent } from './login/login.component';
import { ForgotComponent } from './forgot/forgot.component';
import { SignupComponent } from './signup/signup.component';
import { PasswordChangeComponent } from './password-change/password-change.component';
import { FacilitiesComponent } from './facilities/facilities.component';
import { PatientServiceComponent } from './patient-service/patient-service.component';
import { BedAllocationComponent } from './bed-allocation/bed-allocation.component';
import { BillingComponent } from './billing/billing.component';
import { AdminComponent } from './admin/admin.component';
import { ReceptionComponent } from './reception/reception.component';

@NgModule({
  declarations:[
    AppComponent,
    RoomTypeComponent,
    HomeComponent,
    DetailsComponent,
    ContactUsComponent,
    LoginComponent,
    ForgotComponent,
    SignupComponent,
    PasswordChangeComponent,
    FacilitiesComponent,
    PatientServiceComponent,
    BedAllocationComponent,
    BillingComponent,
    AdminComponent,
    ReceptionComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [RoomTypeComponent]
})
export class AppModule { }
