import { Component } from '@angular/core';

@Component({
  selector: 'app-patient-service',
  templateUrl: './patient-service.component.html',
  styleUrl: './patient-service.component.css'
})
export class PatientServiceComponent {

}
