import { Component } from '@angular/core';

@Component({
  selector: 'app-facilities',
  templateUrl: './facilities.component.html',
  styleUrl: './facilities.component.css'
})
export class FacilitiesComponent {
  showSubtopics: boolean = false;
  admin:boolean=false;
  reportSubtopics:boolean=false;

  toggleSubtopics() {
    this.showSubtopics = !this.showSubtopics;
  }
subtopic(){
  this.admin=!this.admin;
}
report(){
  this.reportSubtopics=!this.reportSubtopics;
}
}
