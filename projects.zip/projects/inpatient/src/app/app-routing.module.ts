import { NgModule } from '@angular/core';
import { RouterModule, Routes,RouterOutlet } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { BedAllocationComponent } from './bed-allocation/bed-allocation.component';
import { BillingComponent } from './billing/billing.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { DetailsComponent } from './details/details.component';
import { ForgotComponent } from './forgot/forgot.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { PasswordChangeComponent } from './password-change/password-change.component';
import { PatientServiceComponent } from './patient-service/patient-service.component';
import { ReceptionComponent } from './reception/reception.component';
import { SignupComponent } from './signup/signup.component';

const routes: Routes = [
  {path:'home',component:HomeComponent},
  {path:'login',component:LoginComponent},
  {path:'details',component:DetailsComponent},
  {path:'contactus',component:ContactUsComponent},
  {path:'forgot',component:ForgotComponent},
  {path:'signup',component:SignupComponent},
  {path:'otp',component:PasswordChangeComponent},
  {path:'patient',component:PatientServiceComponent},
  {path:'bed',component:BedAllocationComponent},
  {path:'billing',component:BillingComponent},
  {path:'admin',component:AdminComponent},
  {path:'receptionist',component:ReceptionComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
