import { Component } from '@angular/core';

@Component({
  selector: 'app-bed-allocation',
  templateUrl: './bed-allocation.component.html',
  styleUrl: './bed-allocation.component.css'
})
export class BedAllocationComponent {

}
