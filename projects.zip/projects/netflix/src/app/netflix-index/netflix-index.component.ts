import { Component } from '@angular/core';

@Component({
  selector: 'app-netflix-index',
  templateUrl: './netflix-index.component.html',
  styleUrl: './netflix-index.component.css'
})
export class NetflixIndexComponent {

}
