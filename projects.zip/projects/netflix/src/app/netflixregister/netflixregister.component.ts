import { Component } from '@angular/core';

@Component({
  selector: 'app-netflixregister',
  templateUrl: './netflixregister.component.html',
  styleUrl: './netflixregister.component.css'
})
export class NetflixregisterComponent {

}
