import { Component } from '@angular/core';

@Component({
  selector: 'app-netflixmain',
  templateUrl: './netflixmain.component.html',
  styleUrl: './netflixmain.component.css'
})
export class NetflixmainComponent {

}
